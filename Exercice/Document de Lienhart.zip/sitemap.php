<?
$id_site = intval(file('includes/id_site.txt')[0]);

$db_server = 'db5001933572.hosting-data.io';
$db_name = 'dbs1582075';
$db_login = 'dbu1385152';
$db_password = 'IiBr8ICK0x!?xHd2PQ1CT4B8';

try {
    $db = new PDO('mysql:host='.$db_server.';dbname='.$db_name.';charset=utf8', $db_login, $db_password);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e) {
    Message('Falta connexão','error');
    exit;
}

$Sites = $db->prepare('SELECT * FROM sites WHERE id=?');
$Sites->execute([$id_site]);
$Site = $Sites->fetch();

$Nom = $Site['nom'];
$Url = $Site['url'];

$ln = "\n";
$tab = "\t";

$xml = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";

$Pages = $db->prepare('SELECT * FROM pages WHERE id_site=? AND off=0');
$Pages->execute([$id_site]);
while ($Page = $Pages->fetch()) {
    switch ($Page['titre_url']) {
        case 'about': $priority = '0.9'; break;
        case 'news': $priority = '0.8'; break;
        case 'contact': $priority = '0.8'; break;
        case 'how-to-help': $priority = '0.9'; break;
        default: $priority = '1.0'; break;
    }

    $page = ($Page['titre_url']!='') ? $Page['titre_url'] : null;

    $xml.=$tab.'<url>'.$ln;
        $xml.=$tab.$tab.'<loc>'.$Url.'/'.$page.'</loc>'.$ln;
        $xml.=$tab.$tab.'<lastmod>'.date('Y-n-d',time()).'</lastmod>'.$ln;
        $xml.=$tab.$tab.'<priority>'.$priority.'</priority>'.$ln;
    $xml.=$tab.'</url>'.$ln;

    // if ($page=='news') {
    //     $news = $db->prepare('SELECT * FROM news WHERE id_site=? AND off = 0 ORDER BY published_date DESC');
    //     $news->execute([$id_site]);
    //     while ($new = $news->fetch()) {
    //         $xml.=$tab.'<url>'.$ln;
    //             $xml.=$tab.$tab.'<loc>'.$Url.'/'.$page.'/'.$new['title_url'].'</loc>'.$ln;
    //             $xml.=$tab.$tab.'<lastmod>'.$new['published_date'].'</lastmod>'.$ln;
    //             $xml.=$tab.$tab.'<priority>0.85</priority>'.$ln;
    //             $xml.=$tab.$tab.'<image:image>'.$ln;
    //                 $xml.=$tab.$tab.$tab.'<image:loc>'.$Url.'/images/'.$page.'/'.$new['cover'].'</image:loc>'.$ln;
    //             $xml.=$tab.$tab.'</image:image>'.$ln;
    //         $xml.=$tab.'</url>'.$ln;
    //     }
    }
}
$xml.='</urlset>';

$file = 'sitemap.xml';
$fileopen=(fopen("$file",'w+'));
fwrite($fileopen,$xml);
fclose($fileopen);
?>
