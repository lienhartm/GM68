<?
include 'templates/contact/params.php';
include 'templates/contact/form.php';
include 'templates/contact/coordonnees.php';
// include 'templates/contact/map.php';
?>