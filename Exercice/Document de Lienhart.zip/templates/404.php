<main>
    <?php
    echo '<article id="home">';
        echo '<h2>Oops: cette page n\'existe pas</h2>';
        echo '<p> Erreur: la page que vous recherchez n\'existe pas ou a été déplacée.</p>';
        echo '<p>Retourner à la page <a href="'.$Url.'">d\'accueil</a>.</p>';
    echo '</article>';
    ?>
</main>
<style>
    main {
        height: auto;
        min-height: 100%;
        padding: 100px;
    }
    main article h2, article, article * {
        text-align: center;
    }
</style>