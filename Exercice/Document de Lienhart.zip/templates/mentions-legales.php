<div class="legal">
<?php
$id = 3;
$Clients = $db->query('SELECT * FROM clients WHERE id = "'.$id.'"');
$Client = $Clients->fetch();

$ml = array(
	'Raison sociale' => $Client['raison_sociale'],
	'Directeur de publication' => $Client['responsable'],
	'Forme juridique' => $Client['forme_juridique'],
	'Siège social' => $Client['adresse'].' - '.$Client['cp'].' '.$Client['ville'],
	'Capital' => ($Client['capital']>0) ? $Client['capital'] : null,
	'RCS' => $Client['rcs'],
	'Numéro d\'identification de TVA' => $Client['num_tva'],
	'Contact' => $Client['email'].' - '.$Client['telephone'],
	'SIREN' => $Client['siren'],
	'SIRET' => $Client['siret'],
	'Code APE' => $Client['code_ape']
);


$Credits = '<p>Les textes ont été produits intégralement par l\'équipe de rédaction du site.<br />Les logos ont été fournis par les partenaires ayant collaboré au projet, avec leur autorisation pour l\'utilisation et l\'exploitation sur le site.<br />Le site utilise la librairie libre et gratuite <a href="https://icomoon.io/" target="_blank">IcoMoon</a> pour les pictogrammes. Le logo et les illustrations ont été produites.</p>';

include '../../tools/mentions-legales.php';
?>
</div>

<script>
$(document).prop('title', 'Mentions légales - <?php echo $Site['nom']; ?>');
</script>