<article class="contact">
    <form method="post" id="contact">
        <h1><strong>Nous contacter</strong></h1>
        <?=$Retour;?>

        <label for="nom">Votre nom&nbsp;:<span>*</span></label>
        <input type="text" id="nom" name="nom" placeholder="John Doe" />

        <label for="prenom">Votre email&nbsp;:<span>*</span></label>
        <input type="text" id="email" name="email" placeholder="john.doe@gmail.com" />

        <label for="telephone">Votre téléphone&nbsp;:</label>
        <input type="text" id="telephone" name="telephone" placeholder="06 00 00 00 00" />

        <label for="message">Votre message&nbsp;:<span>*</span></label>
        <textarea name="message" id="message" placeholder="Votre message"></textarea>

        <p class="submit">
        <button class="g-recaptcha" 
            data-sitekey="<?php echo RECAPTCHA_SITE_KEY; ?>" 
            data-callback='onSubmit' 
            data-size='invisible'
            data-action='submit'>Envoyer</button>
        </p>
    </form>