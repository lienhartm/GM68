    <div class="coordonnees">
		<p class="head"><strong><?=$Site['nom'];?></strong></p>
		<p><a href="tel:<?=str_replace(' ','',$Site['telephone']);?>"><?=$Site['telephone'];?></a></p>
		<p><a href="mailto:<?=$Site['email'];?>"><?=$Site['email'];?></a></p>

    </div>
</article>