<?php
define('RECAPTCHA_SITE_KEY','6Ld3RRUnAAAAAJNOBax1B207jLBZwCpvQr9Hh7h9');
define('RECAPTCHA_SECRET_KEY','6Ld3RRUnAAAAAER8bUm4z17WD92f6rwD6EJGIC_u');

$nom = isset($_POST['nom']) ? htmlspecialchars($_POST['nom']) : null;
$email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : null;
$telephone = isset($_POST['telephone']) ? htmlspecialchars($_POST['telephone']) : null;
$message = isset($_POST['message']) ? htmlspecialchars($_POST['message']) : null;

if (check_token($_POST['g-recaptcha-response'], RECAPTCHA_SECRET_KEY)) {
    if ($nom && $email && $message):
        $adresse_email = filter_var($email, FILTER_VALIDATE_EMAIL);

        if ($adresse_email) {
            if ($message) {
                $adresse_email = filter_var($mail, FILTER_VALIDATE_EMAIL);
                
                $from = 'contact@2r-applications.com';
                $destinataire = $Site['email'];
                $destinataire = 'bigober@gmail.com';
                
                $objet   = 'Nouveau contact depuis le site';
            
                $headers = 'From: '.$from.$eol;
                $headers.= 'Reply-To: '.$email.$eol;
                $headers.= 'MIME-Version: 1.0'.$eol;
                $headers.= 'Content-Type: text/html; charset=utf-8'.$eol;
            
                $msg = '<ul>';
                    $msg.= '<li><strong><u>NOUVEAU MESSAGE:</u></strong></li>';
                    $msg.= '<li>Date: <strong>'.date('d.n.Y h:i:s',time()).'</strong></p>';
                    $msg.= '<li>Nom: <strong>'.$nom.'</strong>';
                    $msg.= '<li>Mail: <strong>'.$email.'</strong>';
                    $msg.= '<li>Téléphone: <strong>'.$telephone.'</strong>';
                $msg.= '</ul>';
            
                $msg.= '<p><strong><u>MESSAGE:</u></strong></p>';
                $msg.= nl2br($message);
                
                if (mail($destinataire, $objet, $msg, $headers)) {
                    $Retour = '<p class="message valid">Nous avons bien reçu votre message et tâcherons d\'y répondre dans les meilleurs délais.<br />Merci.</p>';
                }
                else {
                    $Retour = '<p class="message error">Nous n\'avons pas pu envoyer votre message&nbsp;!<br />Merci de réessayer ultérieurment.</p>';
                }
            }
            else {
                $Retour = '<p class="message error">Le format de l\'adresse email n\'est pas correct.</p>';
            }
        }

    else {
        $Retour = '<p class="message error">Les champs suivis d\'un <span>*</span> sont obligatoires.</p>';
    }
    endif;
}
?>
