	<footer>
		<?php
			echo '<p>';
				echo date("Y",time()).' Copyright © '.$Url.' <span class="trait">-</span> ';
				echo '<a href="'.$Url.'/mentions-legales">Mentions légales</a> <span class="trait">-</span> ';
				echo '<a href="'.$Url.'/cgu">Conditions générales</a> <span class="trait">-</span> ';
				echo '<a href="'.$Url.'/#contact">Contact</a> <span class="trait">-</span> ';
				echo '<a href="https://www.monwebpro.com" target="_blank">MonWebPro.com</a>';
			echo '</p>';
		?>
	</footer>
</body>
</html>

<? include $Tools.'/cookies.php'; ?>