<?php
$page = isset($_GET['page']) ? htmlentities($_GET['page'],ENT_QUOTES,'utf-8') : null;
$data = isset($_GET['data']) ? htmlentities($_GET['data'],ENT_QUOTES,'utf-8') : null;
$niv3 = isset($_GET['niv3']) ? htmlentities($_GET['niv3'],ENT_QUOTES,'utf-8') : null;

include ('../../tools/statistiques.php');

$Pages = $db->query('SELECT * FROM pages WHERE titre_url = "'.$page.'" AND id_site = "'.$id_site.'"');
$Page = $Pages->fetch();
$nbPages = $Pages->rowCount();

$stats = $db->prepare('UPDATE pages SET ping = ping+1 WHERE titre_url = "'.$page.'" AND id_site = "'.$id_site.'"');
$stats->execute();

$canonical = $Url.$_SERVER['REQUEST_URI'];
$og_image = null;
?>
<!doctype html>
<html>
<head>
	<title><?php echo $Page['meta_title']; ?></title>

    <link rel="canonical" href="<?=$canonical;?>" />
    <link rel="icon" href="<?php echo $Url.'/images/favicon.ico'; ?>" />
	<link rel="shortcut icon" sizes="192x192" href="<?php echo $Url.'/images/favicon192.ico'; ?>" />
	<link rel="apple-touch-icon" href="<?php echo $Url.'/images/favicon.ico'; ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <link href="<?php echo $Url.'/styles/knacss.css'; ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo $Url.'/styles/styles.css'; ?>" rel="stylesheet" type="text/css" />
    <? if (file_exists('./styles/'.$page.'.css')): ?>
	<link href="<?php echo $Url.'/styles/'.$page.'.css'; ?>" rel="stylesheet" type="text/css" />
    <? elseif (!$page): ?>
	<link href="<?php echo $Url.'/styles/home.css'; ?>" rel="stylesheet" type="text/css" />
    <? endif; ?>

	<meta charset="utf-8" />
    <meta http-equiv="content-language" content="fr" />
	<meta name="description" content="<?php echo $Page['meta_desc']; ?>" />
	<meta name="copyright" content="<?php echo $Nom; ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1">

    <meta property="og:url"           content="<?=$canonical;?>" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="<?=$Page['meta_title'];?>" />
    <meta property="og:description"   content="<?=$Page['meta_desc'];?>" />
    <? if ($og_image!=''): ?>
    <meta property="og:image"         content="<?=$og_image;?>" />    
    <? endif; ?>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="<?php echo $Url.'/scripts/scripts.js'; ?>"></script>
    <? if (file_exists('./styles/'.$page.'.css')): ?>
    <script src="<?php echo $Url.'/scripts/'.$page.'.js'; ?>"></script>
    <? elseif (!$page): ?>
    <script src="<?php echo $Url.'/scripts/home.js'; ?>"></script>
    <? endif; ?>

    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "<?=$Site['type'];?>",
        "@name": "<?=$Site['name'];?>",
        "@url": "<?=$Url;?>",
        "@logo": "<?=$Url;?>/images/",
        "@sameAs": [
            "https://www.facebook.com/",
        ]
        }
    </script>

    <!-- Google Tag Manager //-->
</head>
<body>
<header>
	<div class="logo">
		<a href="<?=$Url;?>">
            <strong>
                <img src="<?=$Logo;?>" alt="<?=$Nom;?>" />
            </strong>
        </a>
	</div>
	
    <?php include 'menu.php'; ?>
</header>