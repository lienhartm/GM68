<main>
	<?php
		if (file_exists('templates/'.$Page['template'].'.php')) include 'templates/'.$Page['template'].'.php';
		else if (file_exists('templates/'.$page.'.php')) include 'templates/'.$page.'.php';
		else if ($page='') include 'templates/home.php';
		else include 'templates/404.php';
	?>
</main>