<?php
function Message($Message,$class) {
	$Retour = '<p class="message '.$class.'">';
	if ($class=='valid') $Retour.= '<span class="icon">&#xea52;</span>';
	else if ($class=='error') $Retour.= '<span class="icon">&#xea0d;</span>';
	else $Retour.= '<span class="icon">&#xea0c;</span>';
	$Retour.= $Message;
	$Retour.= '</p>';
	
	return $Retour;
}
function Redirection($Lien) {
	echo '<script>';
	echo 'document.location.href="'.$Lien.'";';
	echo '</script>';
}
function check_token($token,$secret_key) {
	$verif_url  = "https://www.google.com/recaptcha/api/siteverify?secret=$secret_key&response=$token";
	$curl = curl_init($verif_url);
	curl_setopt($curl, CURLOPT_HEADER, false);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	$verif_response = curl_exec($curl);
	if ( empty($verif_response) ) return false;
	else { 
		$json = json_decode($verif_response);
		return $json->success;
	}
}
function urlify($text) {
    // Strip html tags
    $text=strip_tags($text);
    // Replace non letter or digits by -
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    // Transliterate
    setlocale(LC_ALL, 'en_US.utf8');
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    // Remove unwanted characters
    $text = preg_replace('~[^-\w]+~', '', $text);
    // Trim
    $text = trim($text, '-');
    // Remove duplicate -
    $text = preg_replace('~-+~', '-', $text);
    // Lowercase
    $text = strtolower($text);
    // Check if it is empty
    if (empty($text)) { return 'n-a'; }
    // Return result
    return $text;
}
?>