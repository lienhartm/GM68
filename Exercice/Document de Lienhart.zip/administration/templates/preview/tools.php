<div class="tools">

</div>

<style>
div.tools {
	width: 400px;
	height: 100%;
	position: absolute;
	top: 0;
	right: 0;
	background: #555;
	box-shadow: 0 0 2px 2px rgba(0,0,0,0.3);

}
</style>