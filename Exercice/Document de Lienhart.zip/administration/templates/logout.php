<?
session_destroy();
Redirection('https://www.monwebpro.com');
?>
