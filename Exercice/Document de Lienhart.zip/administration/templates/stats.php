<?
$view = isset($_GET['view']) ? htmlspecialchars($_GET['view']) : null;
?>
<div class="header">
    <div class="center">
        <ul class="ariane">
            <li><a href="<?=$Url;?>">Admin</a></li>
            <li><span>|</span><a href="<?=$Url.'/?page=stats';?>">Statistiques</a></li>
        </ul>

        <h3><strong>Statistiques</strong></h3>
    </div>
</div>

<div class="main">
    <ul class="rapports">
        <?php
            $dir = scandir('./templates/stats',1);
            foreach ($dir as $rep) {
                if (preg_match('#.pdf$#',$rep)) {
                    $mois = intval(substr($rep,5,2));
                    $annee = substr($rep,0,4);
                    ?>
                        <li>
                            <? if ($rep==$view): ?>
                                <a href="<?=$Url.'/?page='.$page.'&view='.$rep;?>" class="selected"><?=$Mois[$mois].' '.$annee;?></a>
                            <? else: ?>
                                <a href="<?=$Url.'/?page='.$page.'&view='.$rep;?>"><?=$Mois[$mois].' '.$annee;?></a>
                            <? endif; ?>
                        </li>
                    <?
                }
            }
        ?>
    </ul>
    <? if ($view): ?>
        <iframe src="./templates/stats/<?=$view;?>"></iframe>
    <? endif; ?>
</div>