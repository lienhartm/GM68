<?php
$view = isset($_GET['device']) ? htmlentities($_GET['device']) : null;
?>
<div class="content">
<h3>
	<strong>Aperçu</strong>
	
	<ul class="devices">
		<?php
			$devices = array(
				'&#xe956;'=>'', // desktop
				// '&#xe957;'=>'laptop', // laptop
				'&#xe95a;'=>'tablet', // tablet
				'&#xe958;'=>'phone', // phone
			);
			foreach ($devices as $d=>$device) {
				echo '<li>';
					if ($view==$device) echo '<a href="'.$Url.'/?page='.$page.'&device='.$device.'" class="icon selected">';
					else echo '<a href="'.$Url.'/?page='.$page.'&device='.$device.'" class="icon">';
						echo $d;
					echo '</a>';
				echo '</li>';
			}
		?>
	</ul>
</h3>	
<?php
$Sites = $db->query('SELECT * FROM users INNER JOIN sites ON users.id_site = sites.id WHERE users.id = "'.$_SESSION['id_user'].'"');
$Site = $Sites->fetch();
$url = $Site['url'];

switch ($view) {
	case 'phone': $width = '420px'; break;
	case 'tablet': $width = '768px'; break;
	default: $width = '100%'; break;
}

?>
<div class="preview" style="width: <?php echo $width; ?>;">
<iframe src="<?php echo $url; ?>"></iframe>
</div>
