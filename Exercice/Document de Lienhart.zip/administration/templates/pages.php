<?
if ($action) include 'templates/'.$page.'/'.$action.'.php';
else include 'templates/'.$page.'/index.php';
?>