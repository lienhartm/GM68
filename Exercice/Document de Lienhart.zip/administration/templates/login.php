<?php
$user = isset($_GET['user']) ? $_GET['user'] : null;
$auth = isset($_GET['auth']) ? $_GET['auth'] : null;

$Utilisateurs = $db->prepare('SELECT id, id_site, email, password, type, auth FROM users WHERE login = :user AND auth = :auth');
$Utilisateurs->execute(array('user' => $user, 'auth' => $auth));
$Utilisateur = $Utilisateurs->fetch();

if ($user) {
	if (!$Utilisateur) {
		$Retour = 'Mauvais identifiant ou mot de passe !';
	}
	else {
		$_SESSION['login']=1;
		$_SESSION['id_user']=$Utilisateur['id'];
		$_SESSION['id_site']=$Utilisateur['id_site'];
		$_SESSION['domain']=$user;
		$_SESSION['email']=$Utilisateur['email'];
		$_SESSION['type']=$Utilisateur['type'];
		$_SESSION['auth']=$Utilisateur['auth'];
		$_SESSION['password']=password_hash($_GET['password'], PASSWORD_DEFAULT);
	}
}

Redirection($Url);
?>
