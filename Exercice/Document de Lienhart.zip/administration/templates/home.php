<div id="home">
    <h1>
        <div class="logo"><img src="<?=$Url;?>/images/mwgest.png" alt="Tableau de bord"></div>
        <a class="close icon" href="<?=$Url;?>?page=logout">&#xe9b6;</a>
    </h1>

    <div class="apps">
        <?
            // include 'templates/home/page.php';
        ?>
    </div>
</div>

