<nav>
<?php
echo '<ul>';

    $Menus = $db->query('SELECT * FROM applications INNER JOIN apps_users ON applications.id = apps_users.id_app WHERE id_user = "'.$_SESSION['id_user'].'" ORDER BY ordre');
	
	while ($Menu = $Menus->fetch()) {
		echo '<li>';
			if ($page==$Menu['name_url']) echo '<a href="'.$Url.'/?page='.$Menu['name_url'].'" class="active">';
			else echo '<a href="'.$Url.'/?page='.$Menu['name_url'].'">';
				echo '<span class="icon">'.$Menu['icon'].'</span>';
				echo '<strong>'.$Menu['name'].'</strong>';
			echo '</a>';
		echo '</li>';
	}
	echo '<li><a href="'.$Url.'/?page=logout"><span class="icon">&#xe9b6;</span><strong>Déconnexion</strong></a></li>';
echo '</ul>';
?>
</nav>
