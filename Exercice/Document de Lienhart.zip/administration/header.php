<?php
if ($_GET['page']!='login') {
    if ($_SESSION['login']!=1) {
		Redirection($Url.'/?page=logout');
		die();
    }
}

$page = isset($_GET['page']) ? htmlentities($_GET['page'],ENT_QUOTES,'utf-8') : null;
$meta_title = ($page != '') ? ucfirst($page).' - ' : null;

$action = isset($_GET['action']) ? htmlspecialchars($_GET['action']) : null;
?>
<!doctype html>
<html>
<head>
	<title><?php echo $meta_title.'MWP Gest'; ?></title>
	<meta charset="utf-8" />
	<base href="<?php echo $Url; ?>"/>
	<meta http-equiv="content-language" content="pt" />
	<meta name="description" content="<?php echo $Page['meta_desc']; ?>" />
	<meta name="keywords" content="<?php echo $Page['meta_keywords']; ?>" />
	<meta name="copyright" content="<?php echo $Nom; ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="icon" href="<?php echo $Url.'/images/monwebpro-favicon.ico'; ?>" />
	<link rel="shortcut icon" sizes="192x192" href="<?php echo $Url.'/images/monwebpro-icon.ico'; ?>" />
	<link rel="apple-touch-icon" href="<?php echo $Url.'/images/monwebpro-icon.ico'; ?>">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="<?php echo $Url.'/scripts/scripts.js'; ?>"></script>
	
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
	<link href="<?php echo $Url.'/styles/knacss.css'; ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo $Url.'/styles/styles.css'; ?>" rel="stylesheet" type="text/css" />
    <? if (file_exists('./styles/'.$page.'.css')): ?>
	<link href="<?php echo $Url.'/styles/'.$page.'.css'; ?>" rel="stylesheet" type="text/css" />
    <? elseif ($page==''): ?>
    <link href="<?php echo $Url.'/styles/home.css'; ?>" rel="stylesheet" type="text/css" />
    <? endif; ?>
</head>
<body>
<header>
	<div class="content">
		<h1>
			<?php echo '<a href="'.$Url.'"><img src="'.$Url.'/images/mwgest.png" alt="Tableau de bord" /></a>'; ?>
		</h1>
	
		<?php include 'menu.php'; ?>
	</div>
</header>