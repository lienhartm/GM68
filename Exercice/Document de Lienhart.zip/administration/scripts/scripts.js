$(document).ready(function(){
	$('.slider').bxSlider({
		auto: true,
		speed: 500,
		pager: true,
		controls: true
	});
});


$(function() {
	var header = $("header");
	$(window).scroll(function() {
		var scroll = $(window).scrollTop();

		if (scroll >= 10) {
			header.addClass('mini');
		} else {
			header.removeClass("mini");
		}
	});
	
	$("a[href*='#']:not([href='#'])").click(function() {
		if (
			location.hostname == this.hostname
			&& this.pathname.replace(/^\//,"") == location.pathname.replace(/^\//,"")
		) {
			var anchor = $(this.hash);
			anchor = anchor.length ? anchor : $("[name=" + this.hash.slice(1) +"]");
			if ( anchor.length ) {
				$("html, body").animate( { scrollTop: anchor.offset().top - 20 }, 500);
			}
		}
	});
});