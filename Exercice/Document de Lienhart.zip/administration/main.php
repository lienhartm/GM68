<main>
	<?php
		if (!$page) include 'templates/home.php';
		else {
			if (file_exists('templates/'.$page.'.php')) include 'templates/'.$page.'.php';
			else echo 'La page n\'existe pas.';
		}
	?>
</main>