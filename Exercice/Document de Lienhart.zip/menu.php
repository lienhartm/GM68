<nav>
    <ul>
        <?
	        $Menus = $db->prepare('SELECT * FROM pages WHERE top=1 AND id_site=? AND off=0 ORDER BY ordre, id');
	        $Menus->execute([$id_site]);
            while ($Menu = $Menus->fetch()):
                $MenuUrl = ($Menu['titre_url'] != '') ? $Url.'/'.$Menu['titre_url'] : $Url; ?>
            
                <li>
                    <a href="<?=$MenuUrl;?>" <?=($page==$Menu['titre_url']) ? 'class="active"' : null;?>>
                        <?=($Menu['picto']!='') ? '<span class="icon">'.$Menu['picto'].'</span>' : null; ?>
                        <strong><?=$Menu['titre'];?></strong>
                    </a>
                </li>
            <?
            endwhile;
        ?>
    </ul>
</nav>